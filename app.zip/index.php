<?php
 header("location: public/"); 
