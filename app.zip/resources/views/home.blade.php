@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <h2 class="text-black text-center bg-warning bg-gradient" style="--bs-bg-opacity: .6;">Olá,
                    seja bem vindo ao
                    {{ __('Fifa Mobile App') }}
                </h2>
            </div>
        </div>
    </div>
@endsection
