

<?php $__env->startSection('content'); ?>
    <div class="card border-warning mb-3 col-6" style="margin: 0 auto; float: none;margin-bottom: 10px;">
        <div class="card-header"><b><?php echo e(__('Manutenção no Cadastro de Time')); ?></b></div>
        <div class="card-body">
            <h5 class="card-title"><?php echo e(__('Informe o nome e usuário do time')); ?></h5>
            <form action="<?php echo e(route('adicionar_team')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="row g-6 align-items-center">
                    <div class="col-10">
                        <div class="mb-3">
                            <label for="name" class="form-label"><?php echo e(__('Nome')); ?></label>
                            <input type="text" class="form-control" name="name" id="name" aria-hidden="true"
                                required>
                        </div>
                        <div class="mb-3">
                            <label for="userteam" class="form-label"><?php echo e(__('Usuário')); ?></label>
                            <input type="text" class="form-control" name="userteam" id="userteam" required>
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-floppy-o fa-lg"
                                    aria-hidden="true"></i><?php echo e(__('Salvar')); ?></button>
                            <a class="btn btn-danger" href="<?php echo e(route('home')); ?>" role="button"><i class="fa fa-ban fa-lg"
                                    aria-hidden="true"></i><?php echo e(__('Cancelar')); ?></a>
                        </div>
                    </div>
                </div>
            </form>

            <?php if(isset($msgadd)): ?>
                <div class="alert alert-success alert-dismissible fade show mt-3" role="alert"><i class="fa fa-info fa-lg"
                        aria-hidden="true"></i><?php echo e($msgadd); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if(isset($msgreerr)): ?>
                <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert"><i
                        class="fa fa-exclamation-triangle fa-lg" aria-hidden="true"></i><?php echo e($msgreerr); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fifamobile\resources\views/team\team-create.blade.php ENDPATH**/ ?>