

<?php $__env->startSection('content'); ?>
    <div class="card border-warning mb-3 col-6" style="margin: 0 auto; float: none;margin-bottom: 10px;">
        <div class="card-header"><b>Manutenção no Cadastro de Temporada</b></div>
        <div class="card-body">
            <h5 class="card-title">Informe o nome da temporada</h5>
            <form action="<?php echo e(route('adicionar_season')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="row g-6 align-items-center">
                    <div class="col-10">
                        <div class="mb-3">
                            <label for="name" class="form-label">Nome</label>
                            <input type="text" class="form-control" name="name" id="name" aria-hidden="true"
                                required>
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-floppy-o fa-lg"
                                    aria-hidden="true"></i>Salvar</button>
                            <a class="btn btn-danger" href="<?php echo e(route('home')); ?>" role="button"><i class="fa fa-ban fa-lg"
                                    aria-hidden="true"></i>Cancelar</a>
                        </div>
                    </div>
                </div>
            </form>

            <?php if(isset($msgadd)): ?>
                <div class="alert alert-success alert-dismissible fade show mt-3" role="alert"><i class="fa fa-info fa-lg"
                        aria-hidden="true"></i><?php echo e($msgadd); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if(isset($msgreerr)): ?>
                <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert"><i
                        class="fa fa-exclamation-triangle fa-lg" aria-hidden="true"></i><?php echo e($msgreerr); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fifamobile\resources\views/season\season-create.blade.php ENDPATH**/ ?>