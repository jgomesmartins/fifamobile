<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <h2 class="text-black text-center bg-warning bg-gradient" style="--bs-bg-opacity: .6;">Olá,
                    seja bem vindo ao
                    <?php echo e(__('Fifa Mobile App')); ?>

                </h2>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fifamobile\resources\views/home.blade.php ENDPATH**/ ?>