

<?php $__env->startSection('content'); ?>

<div class="card border-warning mb-2 col-7" style="margin: 0 auto; float: none;margin-bottom: 10px;">
    <div class="card-header"><b>Lista times cadastrados</b></div>
    <div class="card-body">
    

      <table id='table-teams' class="table table-striped table-hover">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Nome</th>
            <th scope="col">Usuário</th>
            <th scope="col">Ação</th>
           </tr>
        </thead>
        <tbody>

        <?php
          foreach ( $teams as $team ) {

              echo "<tr><td><b>$team->id</b></td><td>$team->name</td><td>$team->user</td>
              <td>
              <a data-bs-toggle='modal' data-bs-target='#ModalDelete' href='#'><i class='fa fa-trash fa-lg' aria-hidden='true'></i></a>
              <a data-bs-toggle='modal' data-bs-target='#ModalEdit' href='#'><i class='fa fa-pencil fa-lg' aria-hidden='true'></i></a>
              </td>
              </tr>";
        }
         ?>

        </tbody>
      </table>
     
     </div>
     <div class="card-footer">
      <p><b>Total de registros: <?php echo count($teams)?></b></p>
      <?php if(isset($msgadd)): ?>
      <div class="alert alert-success alert-dismissible fade show mt-3" role="alert"><i class="fa fa-info fa-lg" aria-hidden="true"></i><?php echo e($msgadd); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>
      <?php endif; ?>
      
      <?php if(isset($msgreerr)): ?>
      <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert"><i class="fa fa-exclamation-triangle fa-lg" aria-hidden="true"></i><?php echo e($msgreerr); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>
      <?php endif; ?>
    </div>


  </div>
 
<!-- Modal ModalDelete -->
<div class="modal fade" id="ModalDelete" tabindex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="ModalLabel">Confirmação</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <h5 class="text-danger">Deseja realmente excluir o time selecionado?</h5>
        <form action="<?php echo e(route('delete_team')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="mb-3">
            <label for="id" class="col-form-label">ID:</label>
            <input readonly type="text" class="form-control" name='id' id="id">
          </div>

          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Time:</label>
            <input  readonly type="text" class="form-control" name='time' id="time">
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">Jogador:</label>
            <input readonly class="form-control" name='jogador' id="jogador">
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-bs-dismiss="modal"><i class="fa fa-ban fa-lg" aria-hidden="true"></i>Cancelar</button>
            <button type="submit" class="btn btn-danger"><i class="fa fa-trash-o fa-lg" aria-hidden="true"></i>Excluir</button>
          </div>

        </form>
      </div>

   </div>
  </div>
</div>

<!-- Modal ModalDelete -->
<div class="modal fade" id="ModalEdit" tabindex="-1" aria-labelledby="ModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="ModalLabel">Editar Time</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      
        <form action="<?php echo e(route('editar_team')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="mb-3">
            <label for="id" class="col-form-label">ID:</label>
            <input readonly type="text" class="form-control" name='id' id="idedit">
          </div>

          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Time:</label>
            <input  readonly type="text" class="form-control" name='time' id="timeedit">
          </div>

          <div class="mb-3">
            <label for="message-text" class="col-form-label">Jogador:</label>
            <input class="form-control" name='jogador' id="jogadoredit">
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><i class="fa fa-ban fa-lg" aria-hidden="true"></i>Cancelar</button>
            <button type="submit" name="salvarAlteracao" class="btn btn-primary"><i class="fa fa-floppy-o fa-lg" aria-hidden="true"></i>Salvar</button>
          </div>

        </form>
      </div>

   </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fifamobile\resources\views/team-view.blade.php ENDPATH**/ ?>