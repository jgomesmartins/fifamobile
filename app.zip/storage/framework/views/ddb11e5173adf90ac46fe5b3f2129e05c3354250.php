<?php
use App\Models\Season;
?>

<div class="container">
    <div class="row align-items-start">
        <div class="col">
            <form action="" class="">
                <fieldset>
                    <legend><?php echo e(__('Resumo temporadas')); ?></legend>
                    <div class="row align-items-start mb-2">
                        <div class="col-md-3">
                            <label for="idseasonsdash" class="form-label"><?php echo e(__('Temporada')); ?></label>
                            <select id="idseasonsdash" class="form-select">
                                <option value="0"> <?php echo e(__('--Seleciona a temporada --')); ?></option>
                                <?php $__currentLoopData = Season::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>
                    </div>
                    <button type="button" id="btnDashResumodashSeasons" name="btnDashResumodashSeasons"
                        class="btn btn-danger"><i class="fa fa-list-ul fa-lg" aria-hidden="true"></i>Listar</button>
                </fieldset>
            </form>
        </div>
    </div>
    <hr />
    <table id="table-matches-seasons" class="display" style="width:100%">
        <thead>
            <tr>
                <th scope="col"><?php echo e(__('Temporada')); ?></th>
                <th scope="col"><?php echo e(__('Time')); ?></th>
                <th scope="col"><?php echo e(__('Vitorias')); ?></th>
                <th scope="col"><?php echo e(__('Derrotas')); ?></th>
                <th scope="col"><?php echo e(__('Empates')); ?></th>
                <th scope="col"><?php echo e(__('Gols +')); ?></th>
                <th scope="col"><?php echo e(__('Gols -')); ?></th>
                <th scope="col"><?php echo e(__('Saldo Gols')); ?></th>
            </tr>
        </thead>
    </table>

</div>
<?php /**PATH C:\xampp\htdocs\fifamobile\resources\views/dashboard\dashboard-seasons.blade.php ENDPATH**/ ?>